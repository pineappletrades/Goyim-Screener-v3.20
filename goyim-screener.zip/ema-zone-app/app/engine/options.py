"""Shares vs call options for the EMA alerts.

BACKTEST (Strategy Test) - modeled, not real fills:
  Public has no historical option prices, so each past alert's call is priced with Black-Scholes:
    implied vol  = the stock's own realized volatility (the higher of 20- and 60-day) x `iv_mult` (default 1.15,
                   since implied vol usually sits above realized), re-estimated on the exit day too
    strike       = the strike with the chosen delta (0.85 deep in the money ... 0.30 out of the money)
    expiration   = the chosen number of trading days after the alert
    costs        = `spread_pct`% of the premium round trip (half paid buying, half selling)
  The call is opened on the alert day's close and closed on the same day the share trade exits (stop, take
  profit or end of the hold), or at expiration if that comes first. A $10k account spends the same dollars per
  slot on calls as on shares, so it shows the leverage, both ways.
  Not modeled: earnings-day IV crush/spikes, skew, early assignment, dividends, fills worse than the spread.

LIVE FINDER (scan, Gamma page, /options): Public's real option chain for the stock. Every call with a usable
  bid/ask is scored on the strategy's own track record (from the last Strategy Test: win rate, average win,
  average loss, average days held):
    if right  -> stock at +avg_win after avg_days, call re-priced with the time it would have left
    if wrong  -> stock at avg_loss
    expected  = win% x (if right) + (1 - win%) x (if wrong), after paying the ask and selling at the bid side
  The same expectation for shares is the bar a call has to clear (by 1.5x) to be the better buy.
"""
import math
from statistics import NormalDist

import numpy as np

R = 0.04            # risk-free rate used for pricing
_N = NormalDist()
DTE_GRID = [(21, "1 month"), (42, "2 months"), (63, "3 months"), (126, "6 months"), (252, "1 year"), (378, "18 months")]
DELTA_GRID = [0.85, 0.70, 0.50, 0.30]
DEFAULTS = {"dte": 126, "delta": 0.70, "iv_mult": 1.15, "spread_pct": 4.0}


def _r(x, d=2):
    if x is None:
        return None
    x = float(x)
    return None if math.isnan(x) or math.isinf(x) else round(x, d)


def ncdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_call(S, K, T, sig, r=R):
    """Black-Scholes call price (scalar)."""
    if S is None or K is None or S != S or K != K:
        return float("nan")
    if T <= 1e-6 or sig <= 1e-6:
        return max(0.0, S - K)
    v = sig * math.sqrt(T)
    d1 = (math.log(S / K) + (r + 0.5 * sig * sig) * T) / v
    return S * ncdf(d1) - K * math.exp(-r * T) * ncdf(d1 - v)


def bs_delta(S, K, T, sig, r=R):
    if T <= 1e-6 or sig <= 1e-6:
        return 1.0 if S > K else 0.0
    return ncdf((math.log(S / K) + (r + 0.5 * sig * sig) * T) / (sig * math.sqrt(T)))


def implied_vol(price, S, K, T, r=R):
    """IV that makes Black-Scholes match the market price (bisection). None if the price is outside model bounds."""
    if not price or price <= 0 or T <= 0:
        return None
    intrinsic = max(0.0, S - K * math.exp(-r * T))
    if price < intrinsic - 1e-6 or price >= S:
        return None
    lo, hi = 0.01, 5.0
    if bs_call(S, K, T, hi, r) < price:
        return None
    for _ in range(60):
        mid = (lo + hi) / 2
        if bs_call(S, K, T, mid, r) > price:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


def strike_for_delta(S, T, sig, delta, r=R):
    d1 = _N.inv_cdf(min(0.999, max(0.001, delta)))
    return S * math.exp(-d1 * sig * math.sqrt(T) + (r + 0.5 * sig * sig) * T)


def iv_matrix(c, iv_mult=1.15):
    """Estimated implied vol for every day/stock: max(20-day, 60-day realized vol) x iv_mult, kept within 12%..200%."""
    import pandas as pd

    lr = np.log(pd.DataFrame(c)).diff()
    hv20 = lr.rolling(20, min_periods=15).std().values * math.sqrt(252)
    hv60 = lr.rolling(60, min_periods=40).std().values * math.sqrt(252)
    hv = np.fmax(hv20, hv60)
    return np.clip(hv * iv_mult, 0.12, 2.0)


# ----------------------------------------------------------------------
# backtest
# ----------------------------------------------------------------------
def option_trades(trades, fr, ivm, dte, delta, spread_pct=4.0):
    """Turn each share trade into the matching modeled call trade."""
    c = fr["c"]
    n = c.shape[0]
    half = spread_pct / 200.0
    out = []
    for t in trades:
        a = t["a"]
        i, j, S0 = a["i"], a["j"], a["entry"]
        iv0 = ivm[i, j]
        if np.isnan(iv0):
            continue
        T0 = dte / 252.0
        K = strike_for_delta(S0, T0, iv0, delta)
        prem = bs_call(S0, K, T0, iv0)
        if not prem or prem <= S0 * 0.001:
            continue
        buy = prem * (1 + half)
        e = i + dte
        x = min(t["exit_i"], e, n - 1)
        while x > i and np.isnan(c[x, j]):
            x -= 1
        Tx = max(0.0, (e - x) / 252.0)
        ivx = ivm[x, j] if not np.isnan(ivm[x, j]) else iv0
        val = bs_call(float(c[x, j]), K, Tx, ivx)
        sell = val * (1 - half)
        reason = "expired" if x == e and x < t["exit_i"] else t["reason"]
        if x == n - 1 and t["reason"] == "open":
            reason = "open"
        out.append({"a": a, "exit_i": int(x), "exit": float(sell), "entry_px": float(buy), "reason": reason,
                    "ret": (sell / buy - 1) * 100, "days": int(x - i), "bench": t["bench"],
                    "opt": {"K": float(K), "e": int(e), "iv": float(iv0), "prem": float(prem), "dte": dte, "delta": delta}})
    return out


def option_valuer(fr, ivm):
    """Mark an open call to market on day d (for the portfolio's daily equity)."""
    c = fr["c"]

    def val(pz, d):
        o = pz["t"]["opt"]
        S = c[d, pz["j"]]
        if np.isnan(S):
            return None
        iv = ivm[d, pz["j"]] if not np.isnan(ivm[d, pz["j"]]) else o["iv"]
        return bs_call(float(S), o["K"], max(0.0, (o["e"] - d) / 252.0), iv)
    return val


def grid(trades, fr, ivm, start_i, n, slots, portfolio, trade_stats, spread_pct=4.0, status=None):
    """Every expiration x delta combination on the same alerts -> rows with trade stats + portfolio."""
    rows = []
    val = option_valuer(fr, ivm)
    total = len(DTE_GRID) * len(DELTA_GRID)
    k = 0
    for dte, dl in DTE_GRID:
        for delta in DELTA_GRID:
            k += 1
            if status is not None:
                status.update(done=k, total=total, current=f"{dl} calls, delta {delta:.2f}")
            ot = option_trades(trades, fr, ivm, dte, delta, spread_pct)
            pf = portfolio(ot, fr, start_i, n, slots, valuer=val)
            rows.append({"dte": dte, "dte_label": dl, "delta": delta, "label": f"{dl} · delta {delta:.2f}",
                         "stats": trade_stats(ot), "portfolio": {kk: v for kk, v in pf.items() if kk not in ("equity", "equity_days")},
                         "expired": _r(100 * sum(1 for t in ot if t["reason"] == "expired") / len(ot), 1) if ot else None,
                         "avg_cost_pct": _r(np.mean([t["opt"]["prem"] / t["a"]["entry"] * 100 for t in ot]), 1) if ot else None})
    return rows


# ----------------------------------------------------------------------
# live finder on Public's chain
# ----------------------------------------------------------------------
DEFAULT_SCENARIO = {"p_win": 0.55, "up_pct": 12.0, "down_pct": -8.0, "days": 63, "source": "defaults (run the Strategy Test for your own numbers)"}


def scenario_from_result(res):
    """Win rate / average win / average loss / days held from the last Strategy Test (shares, chosen stop)."""
    s = (res or {}).get("stats") or {}
    if not s.get("n") or s.get("avg_win") is None or s.get("avg_loss") is None:
        return dict(DEFAULT_SCENARIO)
    return {"p_win": s["win"] / 100.0, "up_pct": s["avg_win"], "down_pct": s["avg_loss"],
            "days": int(max(5, min(252, s.get("days") or 63))),
            "source": f"your last Strategy Test ({s['n']} trades, {res.get('stop', {}).get('label', '')})"}


def years_left(exp, today=None):
    from datetime import date
    today = today or date.today()
    return max(0.0, (date.fromisoformat(exp) - today).days / 365.0)


def finder(spot, chains, scen=None, min_oi=50, max_spread_pct=12.0, today=None, top=6):
    """Score every call in the chain against the strategy's track record. -> {"best", "candidates", "shares", "verdict", ...}"""
    scen = dict(DEFAULT_SCENARIO, **(scen or {}))
    p, up, dn, days = scen["p_win"], scen["up_pct"] / 100, scen["down_pct"] / 100, scen["days"]
    h_years = days / 252.0
    shares_ev = (p * up + (1 - p) * dn) * 100
    cands, skipped = [], {"spread": 0, "oi": 0, "short": 0, "no_quote": 0}
    # note: deltas below are recomputed from the solved IV
    for exp, rows in sorted(chains.items()):
        T = years_left(exp, today)
        if T < h_years * 1.15:                        # must outlive the expected holding time
            skipped["short"] += sum(1 for r in rows if r["type"] == "call")
            continue
        for r in rows:
            if r["type"] != "call":
                continue
            bid, ask = r.get("bid"), r.get("ask")
            if not ask or ask <= 0 or bid is None:
                skipped["no_quote"] += 1
                continue
            mid = (bid + ask) / 2
            spr = (ask - bid) / mid * 100 if mid > 0 else 999
            if spr > max_spread_pct:
                skipped["spread"] += 1
                continue
            if (r.get("oi") or 0) < min_oi:
                skipped["oi"] += 1
                continue
            K = r["strike"]
            # IV backed out of the actual mid price, so the "if right / if wrong" repricing matches what you'd pay.
            # A price the model can't explain at all (below intrinsic, or needing <3% / >300% vol) is a stale or
            # junk quote, so that contract is skipped rather than trusted.
            iv = implied_vol(mid, spot, K, T)
            if not iv or iv <= 0.03 or iv > 3.0:
                skipped["no_quote"] += 1
                continue
            delta = bs_delta(spot, K, T, iv)
            if not 0.2 <= delta <= 0.95:
                continue
            Th = max(0.0, T - h_years)
            half_out = (ask - bid) / 2
            v_up = max(0.0, bs_call(spot * (1 + up), K, Th, iv * 0.95) - half_out)
            v_dn = max(0.0, bs_call(spot * (1 + dn), K, Th, iv * 1.05) - half_out)
            r_up, r_dn = (v_up / ask - 1) * 100, (v_dn / ask - 1) * 100
            ev = p * r_up + (1 - p) * r_dn
            cands.append({"expiration": exp, "strike": K, "delta": _r(delta, 2), "iv": _r(iv * 100, 1), "bid": bid, "ask": ask,
                          "spread_pct": _r(spr, 1), "oi": r.get("oi"), "volume": r.get("volume"),
                          "cost": _r(ask * 100, 0), "breakeven": _r(K + ask), "breakeven_pct": _r((K + ask) / spot * 100 - 100, 1),
                          "if_right": _r(r_up, 1), "if_wrong": _r(r_dn, 1), "ev": _r(ev, 1),
                          "leverage": _r(delta * spot / ask, 1), "days_left": int(T * 365)})
    cands.sort(key=lambda x: -x["ev"])
    best = cands[0] if cands else None
    # a steadier pick: highest expectation among deep-ish in-the-money calls (stock replacement)
    steady = next((x for x in cands if x["delta"] >= 0.70), None)
    if best is None:
        verdict, why = "Shares", "no liquid call with enough time left"
    elif best["ev"] >= max(shares_ev * 1.5, shares_ev + 5) and best["ev"] > 0:
        verdict, why = "Calls", f"the best call's expected return {best['ev']:+.0f}% beats shares' {shares_ev:+.0f}% by 1.5x or more"
    else:
        verdict, why = "Shares", f"no call beats shares' expected {shares_ev:+.0f}% by 1.5x (best call {best['ev']:+.0f}%)"
    return {"spot": _r(spot), "scenario": scen, "shares": {"ev": _r(shares_ev, 1), "if_right": _r(up * 100, 1), "if_wrong": _r(dn * 100, 1)},
            "best": best, "steady": steady, "candidates": cands[:top], "verdict": verdict, "why": why,
            "checked": len(cands), "skipped": skipped}


def finder_line(f):
    """'📈 Calls or shares: CALLS — 2027-01-15 $180C (Δ0.68) $1,420/contract · expected +24% vs shares +6% · if wrong −41%'"""
    if not f:
        return ""
    sh = f["shares"]
    b = f.get("best")
    if f["verdict"] == "Calls" and b:
        return (f"📈 Calls or shares: <b>CALLS</b> — {b['expiration']} ${b['strike']:g}C (Δ{b['delta']:.2f}) "
                f"${b['ask']:.2f} = ${b['cost']:,.0f}/contract · expected {b['ev']:+.0f}% vs shares {sh['ev']:+.0f}% · "
                f"if right {b['if_right']:+.0f}%, if wrong {b['if_wrong']:+.0f}% · breakeven ${b['breakeven']:,.2f}")
    alt = f" (best call {b['expiration']} ${b['strike']:g}C: expected {b['ev']:+.0f}%, if wrong {b['if_wrong']:+.0f}%)" if b else ""
    return f"📈 Calls or shares: <b>SHARES</b> — expected {sh['ev']:+.0f}% per trade{alt}"
