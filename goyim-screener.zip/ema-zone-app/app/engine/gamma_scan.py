"""Daily gamma scan of the watchlist: one read per ticker from Public's option chains (read-only).

For each ticker:
  gamma        positive (dealers damp moves) or negative (moves can speed up), price vs the gamma flip
  lean         bullish / bearish / mixed from today's estimated net premium, call-vs-put volume,
               where open interest sits (above vs below price) and max pain vs price
  targets      call wall above (upside magnet/ceiling), put wall below (support), expected move
  expiration   the date holding the most gamma (walls weaken after it), OPEX flag
  big trades   today's largest contracts, especially volume > open interest (new positions)
  hedges       unusually large put buying far below price or far out in time ("outlandish" hedges)
All flow numbers are estimates from daily volume (see the Gamma page).
"""
import html
import time
from datetime import date, datetime

E = html.escape


def _m(v):
    if v is None:
        return "–"
    a = abs(v)
    s = "-" if v < 0 else ""
    return f"{s}${a/1e9:.2f}B" if a >= 1e9 else f"{s}${a/1e6:.1f}M" if a >= 1e6 else f"{s}${a/1e3:.0f}K"


def summarize(g):
    spot = g["spot"]
    f = g["flow"]
    strikes = g.get("strikes", [])
    oi_above = sum(r["call_oi"] + r["put_oi"] for r in strikes if r["strike"] > spot * 1.005)
    oi_below = sum(r["call_oi"] + r["put_oi"] for r in strikes if r["strike"] < spot * 0.995)
    call_oi = sum(r["call_oi"] for r in strikes)
    put_oi = sum(r["put_oi"] for r in strikes)
    exps = g.get("expirations", [])
    big_exp = max(exps, key=lambda e: e.get("share") or 0) if exps else None
    near = exps[0] if exps else None

    # lean: each vote is +1 bullish / -1 bearish
    votes, why = 0, []
    if f.get("net_premium"):
        tot = (f.get("call_total") or 0) + (f.get("put_total") or 0)
        if tot and abs(f["net_premium"]) > 0.1 * tot:
            votes += 1 if f["net_premium"] > 0 else -1
            why.append(f"net premium {_m(f['net_premium'])}")
    if f.get("call_total") and f.get("put_total"):
        r = f["call_total"] / max(1.0, f["put_total"])
        if r > 1.5:
            votes += 1
            why.append(f"call $ {r:.1f}× put $")
        elif r < 0.67:
            votes -= 1
            why.append(f"put $ {1 / r:.1f}× call $")
    if near and near.get("max_pain"):
        d = (near["max_pain"] / spot - 1) * 100
        if abs(d) > 1.5:
            votes += 1 if d > 0 else -1
            why.append(f"max pain ${near['max_pain']:,.0f} ({d:+.1f}%)")
    if g.get("flip"):
        if spot >= g["flip"]:
            votes += 1
            why.append("above gamma flip")
        else:
            votes -= 1
            why.append("below gamma flip")
    lean = "bullish" if votes >= 2 else "bearish" if votes <= -2 else "mixed"

    # big / unusual trades and possible hedges
    hot = g.get("hot", [])
    unusual = [h for h in hot if (h.get("vol_oi") or 0) >= 1.0][:3]
    today = date.today()
    hedges = []
    total_prem = (f.get("call_total") or 0) + (f.get("put_total") or 0)
    for h in hot:
        if h["type"] != "put" or h["side"] != "bought":
            continue
        otm = (1 - h["strike"] / spot) * 100
        days = (date.fromisoformat(h["exp"]) - today).days
        share = (h["premium"] or 0) / total_prem * 100 if total_prem else 0
        if (otm >= 10 and share >= 5) or (days >= 60 and (h.get("vol_oi") or 0) >= 2 and share >= 5) or share >= 20:
            hedges.append({**h, "otm_pct": round(otm, 1), "days": days, "share_pct": round(share, 1)})
    pc = put_oi / call_oi if call_oi else None
    return {
        "ticker": g["ticker"], "spot": spot, "regime": g["regime"], "flip": g.get("flip"),
        "above_flip": g.get("flip") is None or spot >= g["flip"], "total_gex": g.get("total_gex"),
        "call_wall": g.get("call_wall_above"), "put_wall": g.get("put_wall_below"),
        "expected_move": g.get("expected_move"), "lean": lean, "lean_votes": votes, "why": why,
        "pc_oi": round(pc, 2) if pc else None, "oi_above_pct": round(100 * oi_above / (oi_above + oi_below), 0) if oi_above + oi_below else None,
        "big_exp": big_exp and {"date": big_exp["date"], "share": big_exp.get("share"), "max_pain": big_exp.get("max_pain")},
        "flow": {k: f.get(k) for k in ("net_premium", "call_total", "put_total", "tilt")},
        "unusual": unusual, "hedges": hedges[:3], "pins": g.get("pins", [])[:3], "pockets": g.get("pockets", [])[:2],
    }


def line(s, detail=True):
    gamma = "🟢 positive" if s["regime"] == "positive" else "🔴 negative"
    lean = {"bullish": "📈 bullish", "bearish": "📉 bearish", "mixed": "↔️ mixed"}[s["lean"]]
    out = [f"<b>{E(s['ticker'])}</b> ${s['spot']:,.2f} · gamma {gamma}{' (above flip)' if s['above_flip'] and s.get('flip') else ' (below flip)' if s.get('flip') else ''} · options lean {lean}"]
    if detail:
        t = []
        if s.get("call_wall"):
            t.append(f"call wall ${s['call_wall']:,.0f} ({(s['call_wall'] / s['spot'] - 1) * 100:+.1f}%)")
        if s.get("put_wall"):
            t.append(f"put wall ${s['put_wall']:,.0f} ({(s['put_wall'] / s['spot'] - 1) * 100:+.1f}%)")
        em = s.get("expected_move")
        if em:
            t.append(f"exp. move ±{em['pct']:.1f}% by {em['date'][5:]}")
        if t:
            out.append("   " + " · ".join(t))
        b = s.get("big_exp")
        f = s["flow"]
        out.append(f"   biggest expiry {b['date'][5:]} ({b['share']:.0f}% of gamma, max pain ${b['max_pain']:,.0f})" if b and b.get("max_pain") else "")
        out.append(f"   premium today: calls {_m(f['call_total'])} · puts {_m(f['put_total'])} · net {_m(f['net_premium'])}"
                   + (f" · P/C OI {s['pc_oi']:.2f}" if s.get("pc_oi") else ""))
        for u in s["unusual"]:
            out.append(f"   🔥 {u['exp'][5:]} ${u['strike']:,.0f}{'C' if u['type'] == 'call' else 'P'} {u['volume']:,} vol (vol/OI {u['vol_oi']:.1f}) {_m(u['premium'])} {u['side']}")
        for h in s["hedges"]:
            out.append(f"   🛡 possible hedge: {h['exp']} ${h['strike']:,.0f}P {h['volume']:,} bought {_m(h['premium'])} · {h['otm_pct']:.0f}% below price · {h['share_pct']:.0f}% of today's premium")
        if s["why"]:
            out.append("   why: " + ", ".join(E(w) for w in s["why"]))
    return "\n".join(x for x in out if x)


def run(api, tickers, status=None, should_stop=lambda: False, log=print):
    st = status if status is not None else {}
    st.update(stage="Gamma scan", total=len(tickers), done=0)
    out, errors = [], []
    for i, t in enumerate(tickers):
        if should_stop():
            break
        st.update(done=i, current=t)
        try:
            g = api.get_gamma(t, "near")
            if g.get("ok"):
                out.append(summarize(g))
            else:
                errors.append(f"{t}: {g.get('error')}")
        except Exception as e:
            errors.append(f"{t}: {e}")
        time.sleep(0.2)
    res = {"as_of": datetime.now().isoformat(timespec="seconds"), "rows": out, "errors": errors[:20]}
    st.update(done=len(tickers), stage="Done")
    return res


def message(res, detail=True, limit=25):
    rows = res.get("rows", [])
    if not rows:
        return "No gamma data for the watchlist" + (f" ({E(res['errors'][0])})" if res.get("errors") else "")
    bull = [r["ticker"] for r in rows if r["lean"] == "bullish"]
    bear = [r["ticker"] for r in rows if r["lean"] == "bearish"]
    neg = [r["ticker"] for r in rows if r["regime"] == "negative"]
    hedge = [r["ticker"] for r in rows if r["hedges"]]
    head = [f"🧲 <b>Watchlist gamma scan</b> · {len(rows)} tickers",
            f"📈 Bullish lean: {', '.join(bull) or 'none'}", f"📉 Bearish lean: {', '.join(bear) or 'none'}",
            f"🔴 Negative gamma (moves can speed up): {', '.join(neg) or 'none'}"]
    if hedge:
        head.append(f"🛡 Possible big hedges: {', '.join(hedge)}")
    order = sorted(rows, key=lambda r: (-len(r["hedges"]), -len(r["unusual"]), -abs(r["lean_votes"])))
    body = [line(r, detail) for r in order[:limit]]
    tail = ["<i>Flow is estimated from daily volume. Open interest updates once a day.</i>"]
    return "\n\n".join(["\n".join(head)] + body + tail)
