"""Market mode and automatic EMA line choice (v3.20).

Market deviation z: how far SPY is from its 200-day EMA (in %), compared with its own last ~2 years
(520 trading days, the current day excluded): z = (distance - average distance) / its standard deviation.

  z <= -1   (or SPY's 20-day volatility z >= 1.5)  -> Bear deviation  (deep discount)
  z >= +1                                          -> Stretched bull
  otherwise                                        -> Normal
Switching back needs the buffer (default 0.3), so it doesn't flip every day: bear ends above -0.7, bull below +0.7.

Line modes:
  fixed : the profile's own fast / slow lines (150/200), as before.
  auto  : the lines for today's market mode (what the research found):
            Normal          150 / 200
            Bear deviation  150 / 200 / 300 (deeper discounts were worth buying)
            Stretched bull  150 only for most stocks (deep lines did badly), 21 / 50 / 150 for leaders
          leader = beta >= 1.2 and beating SPY over the last 63 trading days, checked on the alert day.
  edge  : (Strategy Test, and the scan using the last test's table) walk-forward learned: each market mode x leader cell
          keeps 150/200 unless another line beat 150/200 in that same cell by a clear margin, using only trades whose
          3-month result was already known that day. One line per stock per day (swap, don't add).
"""
import math

import numpy as np

ALL_LINES = (21, 50, 150, 200, 300)
REGIMES = ("bear", "normal", "bull")
NAMES = {"bear": "Bear deviation", "normal": "Normal", "bull": "Stretched bull"}
MODES = {"fixed": "Fixed lines", "auto": "Auto (market mode)", "edge": "Auto v2 (learned, walk-forward)"}

DEFAULTS = {
    "mode": "fixed",
    "bear_z": -1.0, "bull_z": 1.0, "buffer": 0.3, "vol_z": 1.5, "confirm_days": 1,
    "dist_len": 200, "lookback": 520, "vol_days": 20,
    "lines_bear": [150, 200, 300], "lines_normal": [150, 200], "lines_bull": [150], "lines_bull_leaders": [21, 50, 150],
    "leader_beta": 1.2, "leader_days": 63,
    "fast_trend_len": 200,          # lines shorter than 150 also need the close above this EMA (still an uptrend)
    # Auto v2 (edge)
    "edge_horizon": 63, "edge_min_n": 30, "edge_margin": 0.5, "edge_shrink": 60, "edge_conf": 1.28,
}


def cfg(c=None):
    out = dict(DEFAULTS)
    for k, v in (c or {}).items():
        if v is not None and k in DEFAULTS:
            out[k] = v
    for k in ("lines_bear", "lines_normal", "lines_bull", "lines_bull_leaders"):
        out[k] = parse_lines(out[k])
    return out


def parse_lines(v):
    if isinstance(v, str):
        v = [x for x in v.replace("/", ",").replace(" ", ",").split(",") if x.strip()]
    out = []
    for x in v or []:
        try:
            n = int(float(x))
        except (TypeError, ValueError):
            continue
        if 2 <= n <= 400 and n not in out:
            out.append(n)
    return sorted(out)


def from_profile(profile):
    """The line-mode settings of a scan profile (the 'auto_lines' rule), or None when it's off (= fixed lines)."""
    r = ((profile or {}).get("rules") or {}).get("auto_lines") or {}
    if not r.get("enabled"):
        return None
    p = dict(r.get("params") or {})
    m = {"Auto (market mode)": "auto", "Auto v2 (learned from the last Strategy Test)": "edge"}.get(p.get("mode"), p.get("mode") or "auto")
    c = {"mode": m if m in ("auto", "edge") else "auto"}
    for k in ("bear_z", "bull_z", "vol_z", "leader_beta"):
        if p.get(k) not in (None, ""):
            c[k] = float(p[k])
    for k in ("lines_bear", "lines_normal", "lines_bull", "lines_bull_leaders"):
        if p.get(k):
            c[k] = p[k]
    return cfg(c)


def _ema(a, n):
    """EMA down axis 0 of a 1-D or 2-D float array with NaNs (matches pandas ewm(span, adjust=False))."""
    import pandas as pd
    return pd.DataFrame(a).ewm(span=n, adjust=False, ignore_na=True).mean().values if a.ndim == 2 else \
        pd.Series(a).ewm(span=n, adjust=False, ignore_na=True).mean().values


def deviation(spy, c=None):
    """-> (dist %, z, vol_z) arrays for a SPY close array (oldest first). NaN until enough history."""
    import pandas as pd
    c = cfg(c)
    s = pd.Series(np.asarray(spy, dtype="float64"))
    s = s.ffill()
    e = s.ewm(span=int(c["dist_len"]), adjust=False).mean()
    dist = (s / e - 1) * 100
    dist[s.notna().cumsum() < int(c["dist_len"])] = np.nan
    lb, mp = int(c["lookback"]), max(120, int(c["lookback"]) // 2)
    prev = dist.shift(1)
    z = (dist - prev.rolling(lb, min_periods=mp).mean()) / prev.rolling(lb, min_periods=mp).std()
    vol = s.pct_change().rolling(int(c["vol_days"])).std() * math.sqrt(252) * 100
    pv = vol.shift(1)
    vz = (vol - pv.rolling(lb, min_periods=mp).mean()) / pv.rolling(lb, min_periods=mp).std()
    return dist.values, z.values, vz.values, vol.values


def regimes(z, vz, c=None):
    """Market mode per day with the switch-back buffer and an optional N-day confirmation. 0 bear, 1 normal, 2 bull, -1 unknown."""
    c = cfg(c)
    bz, uz, buf, vzt = float(c["bear_z"]), float(c["bull_z"]), float(c["buffer"]), float(c["vol_z"])
    need = max(1, int(c["confirm_days"]))
    out = np.full(len(z), -1, dtype=int)
    state, pend, cnt = 1, None, 0
    for i in range(len(z)):
        zi, vi = z[i], vz[i] if vz is not None else np.nan
        if np.isnan(zi):
            continue
        vhi = (not np.isnan(vi)) and vi >= vzt
        if state == 0:
            want = 0 if (zi <= bz + buf or ((not np.isnan(vi)) and vi >= vzt - buf)) else (2 if zi >= uz else 1)
        elif state == 2:
            want = 0 if (zi <= bz or vhi) else (2 if zi >= uz - buf else 1)
        else:
            want = 0 if (zi <= bz or vhi) else (2 if zi >= uz else 1)
        if want != state:
            cnt = cnt + 1 if pend == want else 1
            pend = want
            if cnt >= need:
                state, pend, cnt = want, None, 0
        else:
            pend, cnt = None, 0
        out[i] = state
    return out


def code_name(k):
    return REGIMES[k] if 0 <= k < 3 else None


def lines_for(regime, leader, c=None):
    c = cfg(c) if not (c and isinstance(c.get("lines_normal"), list)) else c
    if regime == "bear":
        return list(c["lines_bear"])
    if regime == "bull":
        return list(c["lines_bull_leaders"] if leader else c["lines_bull"])
    return list(c["lines_normal"])


def is_leader(beta, rs, c=None):
    c = cfg(c) if not c else c
    return beta is not None and rs is not None and not (isinstance(beta, float) and math.isnan(beta)) \
        and beta >= float(c["leader_beta"]) and rs > 0


# ----------------------------------------------------------------------
# live: today's market mode (for the scan, the Today card and Telegram /mode)
# ----------------------------------------------------------------------
_SNAP = {}


def snapshot(engine, c=None, force=False):
    """Today's market mode from SPY's daily bars (cached per day)."""
    from datetime import date
    from .scanner import Context
    c = cfg(c)
    key = (date.today().isoformat(), c["bear_z"], c["bull_z"], c["vol_z"], c["buffer"])
    if not force and key in _SNAP:
        return _SNAP[key]
    ctx = Context(engine, "SPY", {"id": "mode", "fast": 150, "slow": 200}, engine.shared_cache("SPY"))
    bars = ctx.get("bars")
    if bars is None or len(bars) < 300:
        raise RuntimeError("Need SPY's daily bars (Public) for the market mode")
    cl = bars["close"].values.astype("float64")
    dist, z, vz, vol = deviation(cl, c)
    rg = regimes(z, vz, c)
    k = len(cl) - 1
    reg = code_name(int(rg[k]))
    since = k
    while since > 0 and rg[since - 1] == rg[k]:
        since -= 1
    hist_n = min(len(cl), 260)
    out = {"date": bars.index[-1].date().isoformat(), "spy": round(float(cl[k]), 2), "ema": round(float(cl[k] / (1 + dist[k] / 100)), 2),
           "dist": _f(dist[k]), "z": _f(z[k]), "vol": _f(vol[k], 1), "vol_z": _f(vz[k]),
           "regime": reg, "name": NAMES.get(reg, "Unknown"), "since": bars.index[since].date().isoformat(),
           "lines": {"normal": c["lines_normal"], "bear": c["lines_bear"], "bull": c["lines_bull"], "bull_leaders": c["lines_bull_leaders"]},
           "today_lines": lines_for(reg, False, c), "today_lines_leaders": lines_for(reg, True, c),
           "thresholds": {"bear_z": c["bear_z"], "bull_z": c["bull_z"], "vol_z": c["vol_z"], "buffer": c["buffer"]},
           "history": {"t": [d.date().isoformat() for d in bars.index[-hist_n:]], "z": [_f(x) for x in z[-hist_n:]],
                       "regime": [code_name(int(x)) for x in rg[-hist_n:]]}}
    _SNAP.clear()
    _SNAP[key] = out
    return out


def _f(x, d=2):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) or math.isinf(x) else round(x, d)


# ----------------------------------------------------------------------
# Strategy Test: every touch of every line, by market mode, and the three ways to pick lines
# ----------------------------------------------------------------------
def leader_matrix(c_mat, spy, c=None):
    """(beta, rs) matrices: rolling 252-day beta vs SPY and the stock's leader_days return minus SPY's (pts)."""
    import pandas as pd
    c = cfg(c) if not c else c
    C = pd.DataFrame(c_mat)
    S = pd.Series(np.asarray(spy, dtype="float64"))
    R = C.pct_change(fill_method=None)
    rm = S.pct_change(fill_method=None)
    w, mp = 252, 120
    m_rm = rm.rolling(w, min_periods=mp).mean()
    var = rm.rolling(w, min_periods=mp).var(ddof=0)
    m_r = R.rolling(w, min_periods=mp).mean()
    m_rrm = R.mul(rm, axis=0).rolling(w, min_periods=mp).mean()
    cov = m_rrm.sub(m_r.mul(m_rm, axis=0))
    beta = cov.div(var, axis=0).values
    n = int(c["leader_days"])
    rs = ((C / C.shift(n)).sub(S / S.shift(n), axis=0) * 100).values
    return beta, rs


def touches(fr, lines, p, warm_extra=20):
    """{L: (touched, trend_ok, ema)} for each line length on the whole matrix, same touch rules as the alert."""
    c, l = fr["c"], fr["l"]
    tol = 1 + float(p.get("tolerance", 0.5)) / 100
    import pandas as pd
    out = {}
    trend_len = int(DEFAULTS["fast_trend_len"])
    E_trend = _ema(c, trend_len)
    seen = np.cumsum(~np.isnan(c), axis=0)
    for L in lines:
        E = _ema(c, int(L))
        with np.errstate(invalid="ignore"):
            t = l <= E * tol
            if p.get("hold", True):
                t &= c >= E
            above = c > E
            if int(L) < 150:
                above &= c > E_trend
            up = pd.DataFrame(above.astype(float)).shift(1).rolling(20).sum().values >= float(p.get("above_days", 15))
        if p.get("new_only", True):
            t = t & ~np.vstack([np.zeros((1, t.shape[1]), bool), t[:-1]])
        warm = seen >= max(int(L), trend_len if int(L) < 150 else 0, 60) + warm_extra
        out[int(L)] = (t & up & warm, E)
    return out


def pick(cands, rg_codes, leader_fn, c, mode, edge_state=None):
    """cands: list of (i, j, L). Returns {(i, j): L} chosen for this mode (one line per stock per day)."""
    by = {}
    for i, j, L in cands:
        by.setdefault((i, j), []).append(L)
    out = {}
    for (i, j), Ls in by.items():
        reg = code_name(int(rg_codes[i]))
        if reg is None:
            continue
        lead = leader_fn(i, j)
        if mode == "auto":
            ok = [L for L in Ls if L in lines_for(reg, lead, c)]
            if ok:
                out[(i, j)] = max(ok)            # deepest touched line wins (one alert, not several)
    return out


def bootstrap_diff(a, b, n=1000, seed=7):
    """Month-cluster bootstrap of mean(a) - mean(b). a, b: lists of (month_key, value). -> (diff, lo5, hi95, P(a better))."""
    rng = np.random.default_rng(seed)
    ga, gb = {}, {}
    for m, v in a:
        ga.setdefault(m, []).append(v)
    for m, v in b:
        gb.setdefault(m, []).append(v)
    ms = sorted(set(ga) | set(gb))
    if not ms or not a or not b:
        return None
    ga = {m: np.asarray(v) for m, v in ga.items()}
    gb = {m: np.asarray(v) for m, v in gb.items()}
    sa = np.array([ga[m].sum() if m in ga else 0.0 for m in ms]); na = np.array([len(ga[m]) if m in ga else 0 for m in ms])
    sb = np.array([gb[m].sum() if m in gb else 0.0 for m in ms]); nb = np.array([len(gb[m]) if m in gb else 0 for m in ms])
    d = []
    for _ in range(n):
        k = rng.integers(0, len(ms), len(ms))
        if na[k].sum() and nb[k].sum():
            d.append(sa[k].sum() / na[k].sum() - sb[k].sum() / nb[k].sum())
    if not d:
        return None
    d = np.asarray(d)
    base = float(np.mean([v for _, v in a]) - np.mean([v for _, v in b]))
    return {"diff": _f(base), "lo": _f(np.percentile(d, 5)), "hi": _f(np.percentile(d, 95)), "p_better": _f(100 * (d > 0).mean(), 0)}


# ----------------------------------------------------------------------
# live scan helpers (shared by the ma_touch rule, the v3.20 entry rules and the alert text)
# ----------------------------------------------------------------------
def edge_lines(regime, leader):
    """Auto v2 in the live scan: the lines the last Strategy Test's walk-forward table allows for this cell (None = no table)."""
    from . import store
    try:
        r = store.load("strategy_bt_result.json", None) or {}
    except Exception:
        return None
    t = ((r.get("line_mode") or {}).get("edge_table") or {}).get(f"{regime}:{'leaders' if leader else 'others'}")
    if not t:
        return None
    return sorted(int(L) for L, v in t.items() if (v or {}).get("use"))


def ma_touch_params(profile):
    r = ((profile or {}).get("rules") or {}).get("ma_touch") or {}
    p = {"tolerance": 0.5, "above_days": 15, "hold": True, "new_only": True, "lines": "Both (separate alerts)",
         "side": "From above (pullback to support)"}
    p.update(r.get("params") or {})
    return p


def live_state(ctx):
    """Today's line state for one stock under one profile (cached on the context):
    regime, z, leader (beta, rs), the lines in play, which of them were touched today, and the deepest touched line."""
    cached = ctx.peek("_lm_state")
    if cached is not None:
        return cached
    import pandas as pd
    from . import beta as beta_
    prof = ctx.profile or {}
    c_ = from_profile(prof)
    mp = ma_touch_params(prof)
    bars = ctx.get("bars")
    st = {"mode": c_["mode"] if c_ else "fixed", "regime": None, "z": None, "leader": None, "beta": None, "rs": None,
          "lines": [], "hits": [], "touched_line": None, "series": {}, "note": ""}
    if bars is None or len(bars) < 60:
        ctx.set("_lm_state", st)
        return st
    close, low = bars["close"].astype("float64"), bars["low"].astype("float64")
    spy = None
    try:
        sb = ctx.other("SPY").get("bars")
        spy = sb["close"].reindex(bars.index).ffill().astype("float64") if sb is not None else None
    except Exception:
        spy = None
    if spy is not None:
        st["beta"] = beta_.from_prices(close.values, spy.values)
        n = int((c_ or DEFAULTS)["leader_days"])
        if len(close) > n and np.isfinite(spy.iloc[-1 - n]):
            st["rs"] = float((close.iloc[-1] / close.iloc[-1 - n] - spy.iloc[-1] / spy.iloc[-1 - n]) * 100)
        st["leader"] = is_leader(st["beta"], st["rs"], c_ or cfg())
    kind = prof.get("ma_type", "EMA")
    if c_:
        try:
            snap = snapshot(ctx.engine, c_)
            st["regime"], st["z"] = snap["regime"], snap["z"]
        except Exception as e:
            st["note"] = f"market mode unavailable ({e}); using the Normal lines"
            st["regime"] = "normal"
        lines = None
        if c_["mode"] == "edge":
            lines = edge_lines(st["regime"], bool(st["leader"]))
            if lines is None:
                st["note"] = "no Auto v2 table yet (run the Strategy Test in Auto v2): using the Auto lines"
        st["lines"] = lines if lines is not None else lines_for(st["regime"], bool(st["leader"]), c_)
        kind = "EMA"
    else:
        f, s = int(prof.get("fast", 150)), int(prof.get("slow", 200))
        ln = mp.get("lines", "")
        st["lines"] = sorted({x for x, on in ((f, ln != "Slow MA only"), (s, ln != "Fast MA only")) if on})
    tol = 1 + float(mp.get("tolerance", 0.5)) / 100
    trend_ema = close.ewm(span=int(DEFAULTS["fast_trend_len"]), adjust=False).mean()
    for L in st["lines"]:
        E = close.rolling(L).mean() if kind == "SMA" else close.ewm(span=int(L), adjust=False).mean()
        st["series"][L] = E
        t = low <= E * tol
        if mp.get("hold", True):
            t &= close >= E
        above = close > E
        if L < 150:
            above &= close > trend_ema
        up = above.shift(1).rolling(20).sum() >= float(mp.get("above_days", 15))
        today = bool(t.iloc[-1]) and bool(up.iloc[-1])
        if mp.get("new_only", True) and len(t) > 1:
            today = today and not bool(t.iloc[-2])
        if today:
            st["hits"].append(int(L))
    st["touched_line"] = max(st["hits"]) if st["hits"] else None
    ctx.set("_lm_state", st)
    return st


def staged_note(regime, L):
    """Bear-deviation 300-line entries are the deepest discounts: buy in thirds."""
    if regime == "bear" and L and L >= 300:
        return "staged entry: ⅓ at the line, ⅓ 3% below, ⅓ 6% below"
    return ""


def mode_lines(c, regime, leader):
    """Lines a profile scans in this market: Auto rules, or Auto v2's learned table (falls back to Auto without one)."""
    if c and c.get("mode") == "edge":
        ln = edge_lines(regime, leader)
        if ln is not None:
            return ln
    return lines_for(regime, leader, c)
