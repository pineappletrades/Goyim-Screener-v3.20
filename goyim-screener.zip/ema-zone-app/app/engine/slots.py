"""10 saved parameter slots for the Strategy Test, loadable into the daily scan.

A slot stores the Strategy Test's settings (entry rules, filters, exits, data source, period) plus the headline
results of the run they came from. Loading a slot into the scan copies everything the scan uses into a
strategy's rules: lines, touch tolerance, days above the lines, market cap, FCF / revenue / EPS rules, sector filter,
support checks, macro and theme filters, the debt filter and the beta filter. Exits (stop, take profit, hold time), portfolio
slots and options settings are backtest-only and don't change the scan.
"""
from datetime import datetime

from . import store

FILE = "param_slots.json"
N = 10
LINES = {"both": "Both (separate alerts)", "fast": "Fast MA only", "slow": "Slow MA only"}
SUPPORT_RULES = {"light_pullback": "sup_light_pullback", "strong_close": "sup_strong_close", "absorption": "sup_absorption",
                 "accumulation": "sup_accumulation", "respected": "sup_respected", "no_repeat": "no_repeat_failure"}
SECTOR_CHOICE = {"leading": "Leading only", "leading_improving": "Leading or Improving", "not_lagging": "Anything but Lagging",
                 "undervalued": "Undervalued", "not_overvalued": "Not overvalued"}
BACKTEST_ONLY = ("stop", "take_profit", "hold_days", "slots", "options", "period", "exclude_years", "data_source",
                 "years", "universe", "options_compare", "not_simulated", "time_stop_days", "line_study")
MODE_CHOICE = {"auto": "Auto (market mode)", "edge": "Auto v2 (learned from the last Strategy Test)"}


def load():
    rows = store.load(FILE, None) or []
    rows = (rows + [None] * N)[:N]
    return rows


def save(i, name, params, result=None):
    if not 0 <= int(i) < N:
        raise ValueError("Slot must be 1–10")
    rows = load()
    summ = None
    if result:
        pf, s = result.get("portfolio") or {}, result.get("stats") or {}
        bm = result.get("benchmarks") or {}
        summ = {"cagr": pf.get("cagr"), "maxdd": pf.get("maxdd"), "calmar": pf.get("calmar"), "trades": s.get("n"),
                "win": s.get("win"), "avg": s.get("avg"), "alerts": result.get("alerts_total"),
                "spy_cagr": (bm.get("SPY") or {}).get("cagr"), "qqq_cagr": (bm.get("QQQ") or {}).get("cagr"),
                "from": (result.get("info") or {}).get("first_day"), "to": (result.get("info") or {}).get("last_day")}
    clean = {k: v for k, v in (params or {}).items() if k != "not_simulated"}
    rows[int(i)] = {"name": (name or f"Slot {int(i) + 1}").strip()[:40], "saved": datetime.now().isoformat(timespec="seconds"),
                    "params": clean, "summary": summ}
    store.save(FILE, rows)
    return rows[int(i)]


def clear(i):
    rows = load()
    rows[int(i)] = None
    store.save(FILE, rows)


def to_profile(profile, p):
    """Copy a slot's scan-relevant settings into a strategy profile (returns a new dict)."""
    prof = dict(profile)
    rules = {k: dict(v or {}) for k, v in (prof.get("rules") or {}).items()}

    def setr(rid, enabled, params=None):
        cur = rules.get(rid) or {}
        cur["enabled"] = bool(enabled)
        if params:
            cur["params"] = dict(cur.get("params") or {}, **params)
        rules[rid] = cur

    for k in ("ma_type", "fast", "slow"):
        if p.get(k) is not None:
            prof[k] = p[k]
    setr("ma_touch", True, {"lines": LINES.get(p.get("lines", "both"), LINES["both"]), "tolerance": p.get("tolerance", 0.5),
                            "above_days": p.get("above_days", 15), "hold": bool(p.get("hold", True)),
                            "new_only": bool(p.get("new_only", True))})
    setr("min_market_cap", bool(p.get("min_cap_b")), {"min_b": p.get("min_cap_b") or 0} if p.get("min_cap_b") else None)
    setr("fcf_positive", p.get("use_fcf", True))
    setr("revenue_growth", p.get("use_rev", True), {"min_pct": p.get("rev_min_pct", 0), "quarters": p.get("rev_quarters", 1)})
    setr("eps_up_yoy", p.get("use_eps", True), {"min_quarters": p.get("eps_min_quarters", 1)})
    sk = p.get("sector_filter") or "off"
    setr("leading_sector", sk != "off", {"allow": SECTOR_CHOICE[sk]} if sk in SECTOR_CHOICE else None)
    req = set(p.get("require") or [])
    for k, rid in SUPPORT_RULES.items():
        setr(rid, k in req)
    setr("macro_regime", p.get("macro_min") is not None,
         {"min_score": float(p["macro_min"])} if p.get("macro_min") is not None else None)
    setr("theme_health", p.get("theme_max_risk") is not None,
         {"max_risk": int(p["theme_max_risk"])} if p.get("theme_max_risk") is not None else None)
    setr("debt_filter", p.get("use_debt"), {"max_mcap": p.get("max_debt_mcap", 50) or 0, "max_rev": p.get("max_debt_rev", 150) or 0,
                                             "max_de": p.get("max_debt_equity", 1.5) or 0,
                                             "neg_equity": bool(p.get("debt_block_neg_equity", True)),
                                             "net": bool(p.get("debt_net", False)), "skip_fin": bool(p.get("debt_skip_fin", True)),
                                             "no_data": "Block it" if p.get("debt_no_data") == "block" else "Let it through (often means no debt)"})
    setr("pullback_speed", p.get("use_speed"), {"days": int(p.get("speed_days") or 5), "max_drop": float(p.get("speed_max_drop") or 0),
                                                "max_gap": float(p.get("speed_max_gap") or 0)})
    setr("rel_weakness", p.get("use_rel"), {"days": int(p.get("rel_days") or 20), "max_spy": float(p.get("rel_max_spy") or 0),
                                            "max_sector": float(p.get("rel_max_sec") or 0)})
    setr("touch_number", p.get("use_touches"), {"max_touch": int(p.get("touch_max") or 2), "tolerance": float(p.get("tolerance", 0.5))})
    setr("slow_rising", p.get("use_slope"), {"lookback": int(p.get("slope_days") or 60), "min_pct": float(p.get("slope_min") or 0)})
    setr("no_earnings_soon", p.get("use_earn"), {"min_days": int(round(int(p.get("earn_before") or 10) * 7 / 5))})
    setr("not_extended", p.get("use_ext"), {"max_spread": float(p.get("ext_max_spread") or 0), "max_peak": float(p.get("ext_max_peak") or 0),
                                            "days": int(p.get("ext_days") or 60), "beta_adjust": bool(p.get("ext_beta"))})
    setr("beta_filter", p.get("use_beta"), {"min_beta": float(p.get("beta_min") or 0), "max_beta": float(p.get("beta_max") or 0)})
    lmp = p.get("line_mode") or {}
    lmode = lmp.get("mode", "fixed")
    lines_txt = lambda v, d: ", ".join(str(int(x)) for x in v) if isinstance(v, (list, tuple)) and v else (v or d)
    setr("auto_lines", lmode in MODE_CHOICE, {"mode": MODE_CHOICE.get(lmode, MODE_CHOICE["auto"]),
                                             "bear_z": float(lmp.get("bear_z", -1.0)), "bull_z": float(lmp.get("bull_z", 1.0)),
                                             "vol_z": float(lmp.get("vol_z", 1.5)), "leader_beta": float(lmp.get("leader_beta", 1.2)),
                                             "lines_normal": lines_txt(lmp.get("lines_normal"), "150, 200"),
                                             "lines_bear": lines_txt(lmp.get("lines_bear"), "150, 200, 300"),
                                             "lines_bull": lines_txt(lmp.get("lines_bull"), "150"),
                                             "lines_bull_leaders": lines_txt(lmp.get("lines_bull_leaders"), "21, 50, 150")})
    setr("fast_leaders_only", p.get("use_lead_fast"), {"max_len": int(p.get("lead_fast_max") or 100), "min_beta": float(lmp.get("leader_beta", 1.2))})
    setr("line_rising", p.get("use_line_slope"), {"days": int(p.get("line_slope_days") or 20), "min_pct": float(p.get("line_slope_min") if p.get("line_slope_min") not in (None, "") else 2),
                                                  "fast_only": bool(p.get("line_slope_fast_only", True))})
    setr("bounce_quality", p.get("use_bounce"), {"min_pos": float(p.get("bounce_pos_min") or 0.66), "min_vol": float(p.get("bounce_vol_min") or 0)})
    setr("no_gap_down", p.get("use_gap"), {"days": int(p.get("gap_days") or 10), "max_gap": float(p.get("gap_max") or 5)})
    setr("held_near_line", p.get("use_depth"), {"max_atr": float(p.get("depth_max_atr") or 0.5)})
    setr("breadth_ok", p.get("use_breadth"), {"min_pts": float(p.get("breadth_min") if p.get("breadth_min") not in (None, "") else -2)})
    prof["rules"] = rules
    return prof


def describe(p):
    """Short summary of what a slot filters on."""
    lmode = (p.get("line_mode") or {}).get("mode", "fixed")
    bits = [f"{p.get('ma_type', 'EMA')} {p.get('fast', 150)}/{p.get('slow', 200)}" if lmode not in MODE_CHOICE else
            ("Auto v2 lines (learned)" if lmode == "edge" else "Auto lines by market mode")]
    if p.get("lines") in ("fast", "slow"):
        bits.append(f"{p['lines']} line only")
    if p.get("min_cap_b"):
        bits.append(f"cap ≥ ${p['min_cap_b']}B")
    if p.get("sector_filter") and p["sector_filter"] != "off":
        bits.append(SECTOR_CHOICE.get(p["sector_filter"], p["sector_filter"]).lower() + " sectors")
    if p.get("require"):
        bits.append(f"{len(p['require'])} support check{'s' if len(p['require']) > 1 else ''}")
    if p.get("macro_min") is not None:
        bits.append(f"macro ≥ {p['macro_min']}")
    if p.get("theme_max_risk") is not None:
        bits.append(f"theme < {p['theme_max_risk']} warnings")
    if p.get("use_debt"):
        bits.append("debt filter")
    if p.get("use_speed") and (p.get("speed_max_drop") or p.get("speed_max_gap")):
        bits.append(f"fell ≤ {p.get('speed_max_drop') or '–'}% in {p.get('speed_days') or 5}d" + (f", gap ≤ {p['speed_max_gap']}%" if p.get("speed_max_gap") else ""))
    if p.get("use_rel") and (p.get("rel_max_spy") or p.get("rel_max_sec")):
        bits.append(f"≤ {p.get('rel_max_spy') or '–'} pts weaker than SPY")
    if p.get("use_touches") and p.get("touch_max"):
        bits.append(f"touch #{p['touch_max']} or earlier")
    if p.get("use_slope") and p.get("slope_min") not in (None, ""):
        bits.append(f"slow line ≥ {p['slope_min']}% in {p.get('slope_days') or 60}d")
    if p.get("use_earn") and (p.get("earn_before") or p.get("earn_after")):
        bits.append("no earnings " + " / ".join(x for x in (f"≤ {p['earn_before']}d ahead" if p.get("earn_before") else None,
                                                            f"≤ {p['earn_after']}d after" if p.get("earn_after") else None) if x))
    if p.get("use_ext") and (p.get("ext_max_spread") or p.get("ext_max_peak")):
        xs = [f"fast ≤ {p['ext_max_spread']:g}% above slow" if p.get("ext_max_spread") else None,
              f"peak ≤ {p['ext_max_peak']:g}% above slow" if p.get("ext_max_peak") else None]
        bits.append("not extended (" + ", ".join(x for x in xs if x) + (", × beta" if p.get("ext_beta") else "") + ")")
    if p.get("use_beta") and (p.get("beta_min") or p.get("beta_max")):
        lo, hi = p.get("beta_min") or 0, p.get("beta_max") or 0
        bits.append(f"beta {lo:g}–{hi:g}" if lo and hi else (f"beta ≥ {lo:g}" if lo else f"beta ≤ {hi:g}"))
    for k, lab in (("use_lead_fast", "fast lines: leaders only"), ("use_line_slope", "touched line rising"), ("use_bounce", "strong bounce day"),
                   ("use_gap", "no big gap down"), ("use_depth", "held near the line"), ("use_breadth", "breadth OK")):
        if p.get(k):
            bits.append(lab)
    if p.get("time_stop_days"):
        bits.append(f"out at day {int(p['time_stop_days'])} if red")
    stp = p.get("stop") or {}
    if stp.get("type", "none") != "none":
        lab = stp.get("label") or {"pct": f"{stp.get('value')}% below entry", "atr": f"{stp.get('value')}× ATR",
                                    "trail": f"trailing {stp.get('value')}%", "line": f"{stp.get('value')}% under the touched line",
                                    "slow": f"{stp.get('value')}% under the slow line",
                                    "ema": f"close under the {stp.get('value')} EMA"}.get(stp["type"], stp["type"])
        bits.append(f"stop: {lab}")
    return " · ".join(bits)
