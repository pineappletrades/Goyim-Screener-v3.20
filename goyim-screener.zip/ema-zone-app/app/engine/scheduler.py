"""Runs the scan automatically after the close while the app is open."""
import threading
import time
from datetime import datetime

from . import store


def _hhmm(t):
    try:
        hh, mm = [int(x) for x in str(t).split(":")[:2]]
        return hh, mm
    except ValueError:
        return None


class AutoScanner:
    def __init__(self, run_scan, log=print, run_profile=None, busy=None):
        self.run_scan = run_scan        # callable(send_telegram: bool)
        self.run_profile = run_profile  # callable(schedule item) for the scheduled profile scans
        self.busy = busy or (lambda: False)
        self.log = log
        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._thread.start()

    def next_run_text(self):
        cfg = store.settings().get("auto_scan", {})
        if not cfg.get("enabled"):
            return "Auto-scan off"
        state = store.load("state.json", {})
        today = datetime.now().strftime("%Y-%m-%d")
        when = cfg.get("time", "13:20")
        if state.get("last_auto_scan") == today:
            return f"Auto-scan done today · next at {when}"
        return f"Auto-scan today at {when}"

    def _due(self):
        cfg = store.settings().get("auto_scan", {})
        if not cfg.get("enabled"):
            return False
        now = datetime.now()
        if cfg.get("weekdays_only", True) and now.weekday() >= 5:
            return False
        try:
            hh, mm = [int(x) for x in cfg.get("time", "13:20").split(":")]
        except ValueError:
            return False
        if (now.hour, now.minute) < (hh, mm):
            return False
        return store.load("state.json", {}).get("last_auto_scan") != now.strftime("%Y-%m-%d")

    # ---- scheduled profile scans (Today page: several profiles a day, each at its own time) ----
    def due_profiles(self, now=None):
        now = now or datetime.now()
        today = now.strftime("%Y-%m-%d")
        done = (store.load("state.json", {}) or {}).get("sched_last", {})
        out = []
        for it in store.settings().get("profile_schedule") or []:
            if not it.get("enabled", True):
                continue
            if it.get("weekdays_only", True) and now.weekday() >= 5:
                continue
            hm = _hhmm(it.get("time", ""))
            if not hm or (now.hour, now.minute) < hm or done.get(it.get("id")) == today:
                continue
            # don't run a scan that's long overdue (e.g. the app was closed all day): only within 3 hours of its time
            if (now.hour * 60 + now.minute) - (hm[0] * 60 + hm[1]) > 180:
                continue
            out.append(it)
        return sorted(out, key=lambda x: x.get("time", ""))

    def next_profile_runs(self):
        """{id: text} for the Today page: 'done today', 'today at 13:20', 'Mon at 13:20'..."""
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        done = (store.load("state.json", {}) or {}).get("sched_last", {})
        out = {}
        for it in store.settings().get("profile_schedule") or []:
            t = it.get("time", "")
            if not it.get("enabled", True):
                out[it.get("id")] = "off"
            elif done.get(it.get("id")) == today:
                out[it.get("id")] = f"ran today · next {('Mon' if now.weekday() >= 4 and it.get('weekdays_only', True) else 'tomorrow')} at {t}"
            elif it.get("weekdays_only", True) and now.weekday() >= 5:
                out[it.get("id")] = f"Mon at {t}"
            else:
                hm = _hhmm(t)
                late = hm and (now.hour * 60 + now.minute) - (hm[0] * 60 + hm[1])
                nxt = "Mon" if now.weekday() >= 4 and it.get("weekdays_only", True) else "tomorrow"
                if hm and late is not None and late > 180:
                    out[it.get("id")] = f"missed today (app wasn't running) · next {nxt} at {t}"
                elif hm and late is not None and late >= 0:
                    out[it.get("id")] = f"starting now (waits for a running scan)"
                else:
                    out[it.get("id")] = f"today at {t}"
        return out

    def _mark(self, it):
        state = store.load("state.json", {}) or {}
        state.setdefault("sched_last", {})[it.get("id")] = datetime.now().strftime("%Y-%m-%d")
        store.save("state.json", state)

    def _loop(self):
        while True:
            try:
                if self.run_profile and not self.busy():
                    for it in self.due_profiles():
                        if self.busy():
                            break
                        self._mark(it)
                        self.log(f"Scheduled scan starting: {it.get('label') or it.get('slot')} at {it.get('time')}")
                        try:
                            self.run_profile(it)
                        except Exception as e:
                            self.log(f"Scheduled scan failed: {e}")
                if self._due() and not self.busy():
                    state = store.load("state.json", {})
                    state["last_auto_scan"] = datetime.now().strftime("%Y-%m-%d")
                    store.save("state.json", state)
                    self.log("Auto-scan starting")
                    self.run_scan(True)
            except Exception as e:
                self.log(f"Auto-scan error: {e}")
            time.sleep(30)
