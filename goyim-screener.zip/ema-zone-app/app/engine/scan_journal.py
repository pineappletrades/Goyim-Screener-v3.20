"""Every setup the daily scan (and each scheduled profile scan) alerted, kept so the Today page's alert calendar
can show how each day's alerts did since: P/L from the alert close to the latest price, and vs SPY over the same days.

Saved in scan_journal.json as rows {date, ticker, profile, profile_id, entry, line, grade, sector, source}.
One row per ticker + profile + day (a re-scan the same day doesn't add a second one).
"""
from datetime import date, datetime

from . import store

FILE = "scan_journal.json"
MAX_KEEP = 20000


def add(scan, source="daily"):
    """Record the setups of a finished scan."""
    day = str(scan.get("data_date") or scan.get("run_at", "")[:10] or date.today().isoformat())[:10]
    rows = store.load(FILE, []) or []
    have = {(r["date"], r["ticker"], r.get("profile_id")) for r in rows}
    added = 0
    for r in scan.get("results", []):
        if r.get("status") != "setup" or r.get("close") is None:
            continue
        key = (day, r["ticker"], r.get("profile"))
        if key in have:
            continue
        have.add(key)
        if r.get("touched_line_label"):
            line = r["touched_line_label"]
        elif r.get("touched_fast") and r.get("touched_slow"):
            line = f"{r.get('fast_label', 'fast')} + {r.get('slow_label', 'slow')}"
        elif r.get("touched_slow"):
            line = r.get("slow_label", "slow")
        elif r.get("touched_fast"):
            line = r.get("fast_label", "fast")
        else:
            line = "zone"
        rows.append({"date": day, "ticker": r["ticker"], "profile": r.get("profile_name"), "profile_id": r.get("profile"),
                     "entry": round(float(r["close"]), 4), "line": line, "grade": r.get("grade"), "sector": r.get("sector"),
                     "beta": r.get("beta"), "source": source, "saved": datetime.now().isoformat(timespec="seconds")})
        added += 1
    if added:
        store.save(FILE, rows[-MAX_KEEP:])
    return added


def load():
    return store.load(FILE, []) or []


def graded_days(rows, last_prices, spy_closes, spy_last, today=None):
    """Turn journal rows into calendar days: [{date, alerts: [{ticker, line, entry, ret, vs_SPY, reason, exit, days, ...}]}].
    last_prices: {ticker: latest price}; spy_closes: {YYYY-MM-DD: SPY close}; spy_last: latest SPY price."""
    today = today or date.today()
    days = {}
    for r in rows:
        last = last_prices.get(r["ticker"])
        ret = (last / r["entry"] - 1) * 100 if last and r.get("entry") else None
        spy0 = spy_closes.get(r["date"])
        spy_ret = (spy_last / spy0 - 1) * 100 if spy0 and spy_last else None
        try:
            held = max(0, int(_busdays(date.fromisoformat(r["date"]), today)))
        except Exception:
            held = None
        days.setdefault(r["date"], []).append({
            "ticker": r["ticker"], "line": r.get("line"), "entry": r.get("entry"), "ret": None if ret is None else round(ret, 2),
            "vs_SPY": None if ret is None or spy_ret is None else round(ret - spy_ret, 2), "reason": "now",
            "exit_date": today.isoformat(), "days": held, "sector": r.get("sector"), "beta": r.get("beta"),
            "profile": r.get("profile"), "grade": r.get("grade")})
    return [{"date": d, "alerts": v} for d, v in sorted(days.items(), reverse=True)]


def _busdays(a, b):
    import numpy as np
    return np.busday_count(a, b)
