"""v3.20: automatic EMA line by market mode, and the fast-line (21/50 EMA) entry filters.

Every rule here works with whichever line was touched today (fixed 150/200, or the line Auto picked), so they
behave the same in the daily scan as in the Strategy Test.
"""
from engine.plugin_api import Param, Rule


def _state(ctx):
    from engine import line_mode as lm
    return lm.live_state(ctx)


class AutoLines(Rule):
    id = "auto_lines"
    name = "Auto EMA line by market mode"
    group = "Market"
    description = ("Picks the EMA lines from how far SPY is from its 200-day EMA vs its own last 2 years (the market deviation z). "
                   "Normal: 150/200. Bear deviation (z ≤ −1, or volatility spiking): 150/200/300, deeper discounts. "
                   "Stretched bull (z ≥ +1): 150 only, but 21/50/150 for leaders (beta ≥ 1.2 and beating SPY over 3 months). "
                   "Auto v2 uses the lines the last Strategy Test (run in Auto v2) found worked in each mode. "
                   "Off = the strategy's own fast / slow lines, as before.")
    needs = ["bars"]
    default_enabled = False
    params = [
        Param("mode", "Line choice", "Auto (market mode)", kind="choice",
              choices=["Auto (market mode)", "Auto v2 (learned from the last Strategy Test)"]),
        Param("bear_z", "Bear deviation at z ≤", -1.0, min=-4, max=0, step=0.1),
        Param("bull_z", "Stretched bull at z ≥", 1.0, min=0, max=4, step=0.1),
        Param("vol_z", "Also bear when SPY volatility z ≥", 1.5, min=0, max=5, step=0.1),
        Param("leader_beta", "Leader: beta at least", 1.2, min=0, max=4, step=0.1),
        Param("lines_normal", "Normal lines", "150, 200", kind="text"),
        Param("lines_bear", "Bear deviation lines", "150, 200, 300", kind="text"),
        Param("lines_bull", "Stretched bull lines", "150", kind="text"),
        Param("lines_bull_leaders", "Stretched bull lines for leaders", "21, 50, 150", kind="text"),
    ]

    def check(self, ctx, p):
        from engine import line_mode as lm
        st = _state(ctx)
        reg = lm.NAMES.get(st["regime"], "Unknown")
        z = f"z {st['z']:+.2f}" if st.get("z") is not None else "z n/a"
        lead = " · leader" if st.get("leader") else ""
        return True, f"{reg} ({z}){lead} → EMA {'/'.join(str(x) for x in st['lines'])}" + (f" · {st['note']}" if st["note"] else "")


class FastLeadersOnly(Rule):
    id = "fast_leaders_only"
    name = "Fast lines: leaders only"
    group = "Trend"
    description = ("On lines shorter than N days (the 21 / 50 EMA), only take leaders: beta ≥ 1.2 and beating SPY over the last "
                   "3 months. In the research the fast lines only worked on leaders; on everything else they lagged SPY.")
    needs = ["bars"]
    default_enabled = False
    params = [Param("max_len", "Applies to lines shorter than", 100, unit="days", min=10, max=400, step=10),
              Param("min_beta", "Leader: beta at least", 1.2, min=0, max=4, step=0.1)]

    def check(self, ctx, p):
        st = _state(ctx)
        L = st["touched_line"]
        if not L or L >= p["max_len"]:
            return True, "not a fast-line touch"
        b, rs = st.get("beta"), st.get("rs")
        ok = b is not None and rs is not None and b >= p["min_beta"] and rs > 0
        txt = f"beta {b:.2f}" if b is not None else "beta n/a"
        txt += f", {rs:+.1f} pts vs SPY in 3 months" if rs is not None else ""
        return ok, ("leader: " if ok else "not a leader: ") + txt


class LineRising(Rule):
    id = "line_rising"
    name = "Touched line rising"
    group = "Trend"
    description = "The line it touched is up at least X% over the last N days (a rising floor). By default only checked on fast lines."
    needs = ["bars"]
    default_enabled = False
    params = [Param("days", "Over the last", 20, unit="trading days", min=5, max=120, step=1),
              Param("min_pct", "Up at least", 2.0, unit="%", min=-20, max=50, step=0.5),
              Param("fast_only", "Only check lines shorter than 100 days", True, kind="bool")]

    def check(self, ctx, p):
        st = _state(ctx)
        L = st["touched_line"]
        if not L or (p.get("fast_only", True) and L >= 100):
            return True, "not checked on this line"
        E = st["series"].get(L)
        n = int(p["days"])
        if E is None or len(E) <= n:
            return True, "not enough history"
        chg = float((E.iloc[-1] / E.iloc[-1 - n] - 1) * 100)
        ctx.set("line_slope", round(chg, 2))
        ok = chg >= float(p["min_pct"])
        return ok, f"EMA {L} {chg:+.1f}% over {n}d" + ("" if ok else f" (needs {p['min_pct']:+g}%)")


class BounceQuality(Rule):
    id = "bounce_quality"
    name = "Strong bounce day"
    group = "Trend"
    description = "Today closed in the top part of its range (default top third) and, optionally, on more volume than the 3 pullback days before."
    needs = ["bars"]
    default_enabled = False
    params = [Param("min_pos", "Close at least this far up the day's range", 0.66, unit="(0 = low, 1 = high)", min=0, max=1, step=0.05),
              Param("min_vol", "Volume at least", 0.0, unit="× the prior 3 days (0 = don't check)", min=0, max=5, step=0.1)]

    def check(self, ctx, p):
        b = ctx.get("bars")
        h, l, c, v = (float(b[k].iloc[-1]) for k in ("high", "low", "close", "volume"))
        pos = (c - l) / (h - l) if h > l else 0.5
        ctx.set("bounce_pos", round(pos, 2))
        bad = pos < float(p["min_pos"])
        txt = f"closed {pos * 100:.0f}% up the range"
        if p.get("min_vol"):
            pv = float(b["volume"].iloc[-4:-1].mean())
            vr = v / pv if pv > 0 else None
            if vr is not None:
                ctx.set("bounce_vol", round(vr, 2))
                txt += f", volume {vr:.1f}× the prior 3 days"
                bad |= vr < float(p["min_vol"])
        return (not bad), txt


class NoGapDown(Rule):
    id = "no_gap_down"
    name = "No big gap down lately"
    group = "Trend"
    description = "Skips stocks that gapped down more than X% in the last N days (usually earnings or news)."
    needs = ["bars"]
    default_enabled = False
    params = [Param("days", "In the last", 10, unit="trading days", min=2, max=40, step=1),
              Param("max_gap", "Biggest gap down at most", 5.0, unit="%", min=0, max=30, step=0.5)]

    def check(self, ctx, p):
        b = ctx.get("bars")
        n = int(p["days"])
        g = (b["open"] / b["close"].shift(1) - 1).iloc[-n:] * 100
        mn = float(min(0.0, g.min())) if len(g) else 0.0
        ctx.set("gap_min", round(mn, 1))
        ok = -mn <= float(p["max_gap"])
        return ok, f"biggest gap {mn:+.1f}% in {n}d"


class HeldNearLine(Rule):
    id = "held_near_line"
    name = "Held near the line"
    group = "Trend"
    description = "Today's low didn't knife more than X ATR under the touched line."
    needs = ["bars", "atr"]
    default_enabled = False
    params = [Param("max_atr", "Low at most", 0.5, unit="ATR under the line", min=0, max=5, step=0.1)]

    def check(self, ctx, p):
        st = _state(ctx)
        L = st["touched_line"]
        if not L or L not in st["series"]:
            return True, "no touch today"
        low, atr = float(ctx.get("bars")["low"].iloc[-1]), ctx.get("atr")
        E = float(st["series"][L].iloc[-1])
        d = max(0.0, E - low) / atr if atr else 0.0
        ctx.set("depth_atr", round(d, 2))
        return d <= float(p["max_atr"]), f"low {d:.2f} ATR under EMA {L}"


class BreadthOk(Rule):
    id = "breadth_ok"
    name = "Market breadth OK"
    group = "Market"
    description = "Equal-weight S&P (RSP) vs SPY over the last 20 days at least X points: a broad market, not a few stocks carrying it."
    needs = ["bars"]
    default_enabled = False
    params = [Param("min_pts", "RSP vs SPY at least", -2.0, unit="pts over 20 days", min=-20, max=20, step=0.5)]

    def check(self, ctx, p):
        try:
            r, s = ctx.other("RSP").get("bars"), ctx.other("SPY").get("bars")
            br = float((r["close"].iloc[-1] / r["close"].iloc[-21] - s["close"].iloc[-1] / s["close"].iloc[-21]) * 100)
        except Exception as e:
            return True, f"breadth unavailable ({e})"
        ctx.set("breadth", round(br, 2))
        return br >= float(p["min_pts"]), f"RSP {br:+.1f} pts vs SPY in 20d"
