"""Entry quality: how the stock got to the line (see engine/entry_quality.py)."""
from engine.plugin_api import Param, Rule


class PullbackSpeed(Rule):
    id = "pullback_speed"
    name = "Pullback not too fast"
    group = "Trend"
    description = ("Skips stocks that crashed into the line: fell more than X% from their highest close of the last N days, "
                   "or gapped down more than Y% in that time. A slow drift down is usually profit-taking; a fast drop or gap is usually news.")
    needs = ["bars"]
    default_enabled = False
    params = [
        Param("days", "Look back", 5, unit="trading days", min=2, max=30, step=1),
        Param("max_drop", "Fell at most", 10.0, unit="% from the high close (0 = don't check)", min=0, max=50, step=0.5),
        Param("max_gap", "Biggest gap down at most", 0.0, unit="% (0 = don't check)", min=0, max=30, step=0.5),
    ]

    def check(self, ctx, p):
        import numpy as np
        from engine import entry_quality as eq
        b = ctx.get("bars")
        c, o = np.asarray(b["close"].values, dtype="float64"), np.asarray(b["open"].values, dtype="float64")
        drop, gap = eq.pullback(c, o, len(c) - 1, int(p["days"]))
        ctx.set("pb_drop", None if drop is None else round(drop, 1))
        ctx.set("pb_gap", None if gap is None else round(gap, 1))
        a = {"pb_drop": drop, "pb_gap": gap}
        bad = eq.too_fast(a, {"speed_max_drop": p["max_drop"], "speed_max_gap": p["max_gap"]})
        txt = f"fell {-(drop or 0):.1f}% in {int(p['days'])}d" + (f", biggest gap {gap:+.1f}%" if gap is not None and gap < 0 else "")
        return (not bad), ("too fast: " + txt) if bad else txt


class RelWeakness(Rule):
    id = "rel_weakness"
    name = "Not much weaker than the market"
    group = "Market"
    description = ("Skips stocks that fell much more than SPY (and optionally their sector ETF) over the last N days. "
                   "Falling with the market tends to recover; falling alone usually means a company-specific problem.")
    needs = ["bars"]
    default_enabled = False
    params = [
        Param("days", "Over the last", 20, unit="trading days", min=5, max=120, step=1),
        Param("max_spy", "At most", 8.0, unit="pts weaker than SPY (0 = don't check)", min=0, max=50, step=0.5),
        Param("max_sector", "At most", 0.0, unit="pts weaker than its sector ETF (0 = don't check)", min=0, max=50, step=0.5),
    ]

    def check(self, ctx, p):
        import numpy as np
        from engine import entry_quality as eq
        b = ctx.get("bars")
        n = int(p["days"])
        c = np.asarray(b["close"].values, dtype="float64")
        spy = ctx.other("SPY").get("bars")
        m = np.asarray(spy["close"].reindex(b.index).values, dtype="float64") if spy is not None else None
        rs = eq.relative(c, m, len(c) - 1, n)
        rx = None
        if p["max_sector"]:
            try:
                from engine import sector_filter as sf
                from engine.rotation import SECTOR_ETF
                etf = SECTOR_ETF.get(sf.sector_of(ctx.engine, ctx.ticker, ctx))
                if etf:
                    eb = ctx.other(etf).get("bars")
                    rx = eq.relative(c, np.asarray(eb["close"].reindex(b.index).values, dtype="float64"), len(c) - 1, n)
            except Exception:
                rx = None
        ctx.set("rel_spy", None if rs is None else round(rs, 1))
        bad = eq.too_weak({"rel_spy": rs, "rel_sec": rx}, {"rel_max_spy": p["max_spy"], "rel_max_sec": p["max_sector"]})
        txt = ("n/a vs SPY" if rs is None else f"{rs:+.1f} pts vs SPY") + ("" if rx is None else f", {rx:+.1f} vs sector") + f" in {n}d"
        return (not bad), ("too weak: " + txt) if bad else txt


class TouchNumber(Rule):
    id = "touch_number"
    name = "Early touch of the line"
    group = "Trend"
    description = ("Only the first few touches of the line in the last 12 months (a touch = the low within the tolerance of the line, "
                   "after 10+ days away from it). The first pullback after a run tends to hold best; later ones are an aging trend.")
    needs = ["bars", "ma_fast_series", "ma_slow_series"]
    default_enabled = False
    params = [
        Param("max_touch", "Touch number at most", 2, unit="(1 = first touch only)", min=1, max=10, step=1),
        Param("tolerance", "Counts as a touch within", 0.5, unit="% of the line", min=0, max=5, step=0.1),
    ]

    def check(self, ctx, p):
        import numpy as np
        from engine import entry_quality as eq
        b = ctx.get("bars")
        low = np.asarray(b["low"].values, dtype="float64")
        F = np.asarray(ctx.get("ma_fast_series"), dtype="float64")[-len(low):]
        S = np.asarray(ctx.get("ma_slow_series"), dtype="float64")[-len(low):]
        tol = float(p["tolerance"])
        lt = low[-1]
        # the line being touched today (the slow one if both)
        line = S if lt <= S[-1] * (1 + tol / 100) else F
        n = eq.touch_number(low[-len(line):], line, tol)
        ctx.set("touch_n", n)
        if lt > max(F[-1], S[-1]) * (1 + tol / 100):
            return True, f"not touching a line today (last count {n})"
        ok = n <= int(p["max_touch"])
        nth = {1: "1st", 2: "2nd", 3: "3rd"}.get(n, f"{n}th")
        return ok, f"{nth} touch in 12 months" + ("" if ok else f" (max {int(p['max_touch'])})")
